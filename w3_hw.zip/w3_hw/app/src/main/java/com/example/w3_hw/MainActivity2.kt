package com.example.w3_hw

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)



        val button2 = findViewById<Button>(R.id.button2)
        button2.setOnClickListener {
            //startActivity(Intent(this@MainActivity2, MainActivity::class.java))


            intent?.extras?.let {

                val name1 = it.getString("KeyName")
                val gender1 = it.getString("Keygen")

                val textView4 =findViewById<TextView>(R.id.textView4)
                textView4.text= "name:${name1.toString()}\n"+"gender:${gender1.toString()}"


                val size = findViewById<EditText>(R.id.editTextTextSize)
                val color = findViewById<EditText>(R.id.editTextTextColor)
/*
                println(textView4.getText().toString())
                println(size.getText().toString())
                println(color.getText().toString())
*/

                val bundle = Bundle()
                bundle.putString("Key0",textView4.getText().toString())
                bundle.putString("Key1", size.getText().toString())
                bundle.putString("Key2", color.getText().toString())

                val intent = Intent(this@MainActivity2, MainActivity::class.java)
                intent.putExtras(bundle)
                setResult(Activity.RESULT_OK, Intent().putExtras(bundle))
                finish()

            }

        }




    }
}