package com.example.w3_hw

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
            val intent=Intent(this@MainActivity, MainActivity2::class.java)

            val bundle = Bundle()
            val editname = findViewById<EditText>(R.id.editTextTextPersonName)
            val editgender = findViewById<EditText>(R.id.editTextGender)

            val name = editname.getText().toString()
            val gender = editgender.getText().toString()

            bundle.putString("KeyName",name)
            bundle.putString("Keygen",gender)

            intent.putExtras(bundle)
            startActivityForResult(intent,1)
            //startActivity(intent)
        }



    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        //判斷Intent不能為空，檢查資料是否有數值
        data?.extras?.let {

           if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
                //show返回資料

                findViewById<TextView>(R.id.textView3).text =
                    "${it.getString("Key0")}\n"+
                    "尺寸: ${it.getString("Key1")}\n" +
                    "顏色: ${it.getString("Key2")}\n"


           }
        }
    }
}